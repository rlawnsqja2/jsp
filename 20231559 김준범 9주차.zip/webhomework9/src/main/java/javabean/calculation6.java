package javabean;

public class calculation6 {

}
